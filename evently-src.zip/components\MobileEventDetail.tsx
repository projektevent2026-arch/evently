'use client'

import PosterButton from '@/components/PosterButton'
import EventHero from '@/components/EventHero'
import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import dynamic from 'next/dynamic'
import { supabase } from '@/lib/supabase'
import EventSchedule from '@/components/EventSchedule'
import { useFavorites } from '@/hooks/useFavorites'
import { getEventWithDates } from '@/lib/getEventWithDates'
import EventDatesList from '@/components/EventDatesList'
import AddToCalendarButton from '@/components/AddToCalendarButton'
import { dateRange, isMultiDay, weekdayName, fmtClock, durationBetween, nextTermInfo, nextOccurrence, linkify } from '@/lib/eventFormat'
import { normalizeCategory, CATEGORY_LABELS, CATEGORY_BADGE_CLASSES, type CategoryKey } from '@/lib/eventCategory'

const EventMap = dynamic(() => import('@/components/event-map').then(m => m.EventMap), { ssr: false })

const TABS = ['O wydarzeniu', 'Program', 'Lokalizacja']

// Gradient tła hero per kategoria — używany tylko tutaj, więc zostaje
// lokalny (nie w lib/eventCategory.ts). Rekeyowany na kanoniczne 4
// kategorie: wcześniej "technology" nie miało własnego wpisu i dostawało
// domyślny, szary gradient — teraz spójnie dostaje ten sam co "festyny".
const CAT_GRADIENT: Record<CategoryKey, string> = {
  muzyka: 'from-[#060e18] via-[#0e2040] to-[#2d5cbf]',
  sport: 'from-[#060f1a] via-[#0a1f35] to-[#1a3a5c]',
  kultura: 'from-[#120820] via-[#1e1040] to-[#3d1a6e]',
  festyny: 'from-[#1a0a00] via-[#2d1800] to-[#4a2800]',
}

export default function MobileEventDetail({ slug }: { slug: string }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const isPreview = searchParams.get('preview') === '1'
  const [event, setEvent] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState(0)
  // Ulubione na localStorage — bez kont. Zsynchronizowane z kartami i stroną /ulubione.
  const { isFavorite, toggleFavorite } = useFavorites()

  useEffect(() => {
    async function load() {
      const data = await getEventWithDates(slug, isPreview)
      if (data) {
        setEvent(data)
        // Pobieranie RSVP (kto idzie) usunięte — RSVP wraca w tier D razem z kontami.
      }
      setLoading(false)
    }
    load()
  }, [slug, isPreview])

  const handleShare = async () => {
    if (navigator.share) await navigator.share({ title: event?.title, url: window.location.href })
    else navigator.clipboard.writeText(window.location.href)
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
      <div className="text-green-500 text-sm animate-pulse">Ładowanie...</div>
    </div>
  )

  if (!event) return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
      <div className="text-zinc-500 text-sm">Nie znaleziono wydarzenia.</div>
    </div>
  )

  const cat = normalizeCategory(event.category)
  const gradient = CAT_GRADIENT[cat]
  const tagColor = CATEGORY_BADGE_CLASSES[cat]
  const tagLabel = CATEGORY_LABELS[cat]
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([event.address, event.city].filter(Boolean).join(', '))}`
  const hasTabs = event.schedule && event.schedule.length > 0
  const tabs = hasTabs ? TABS : ['O wydarzeniu', 'Lokalizacja']

  // Godzina w pasku info: z NAJBLIŻSZEGO terminu (nextOccurrence), nie z
  // surowych start_date/end_date — patrz komentarz w EventPageClient.tsx
  // przy tej samej poprawce.
  const occ = nextOccurrence(event)
  const timeLabel = occ.startTime
    ? (occ.endTime && occ.endTime !== occ.startTime ? `${occ.startTime}–${occ.endTime}` : occ.startTime)
    : ''

  const nextTerm = nextTermInfo(event.event_dates)

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white pb-28">

      {isPreview && event.status !== 'published' && (
        <div className="bg-amber-500 text-black text-[11px] font-bold text-center py-1.5">
          🔍 Podgląd administratora — status: {event.status}, jeszcze niepubliczne
        </div>
      )}

      {/* ── HERO ── */}
      <div className={`relative h-52 overflow-hidden bg-gradient-to-br ${gradient}`}>
      <EventHero src={event.cover_image_url || event.image_url} alt={event.title} />
        {/* Top bar */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
          <button
            onClick={() => router.back()}
            className="w-8 h-8 rounded-full bg-black/55 border border-white/18 flex items-center justify-center text-white text-sm"
          >
            ←
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => toggleFavorite(event.id)}
              aria-label={isFavorite(event.id) ? 'Usuń z ulubionych' : 'Dodaj do ulubionych'}
              className={`w-8 h-8 rounded-full border flex items-center justify-center text-base transition-colors ${
                isFavorite(event.id)
                  ? 'bg-red-500 border-red-500 text-white'
                  : 'bg-black/55 border-white/18 text-white'
              }`}
            >
              {isFavorite(event.id) ? '♥' : '♡'}
            </button>
            <button
              onClick={handleShare}
              className="w-8 h-8 rounded-full bg-black/55 border border-white/18 flex items-center justify-center text-sm text-white"
            >
              ↗
            </button>
            <PosterButton src={event.image_url || event.cover_image_url} />
          </div>
        </div>

        {/* Bottom content */}
        <div className="absolute bottom-0 left-0 right-0 p-3.5 z-10">
          <span className={`text-[8px] font-black px-2.5 py-1 rounded-lg mb-2 inline-block ${tagColor}`}>
            {tagLabel}
          </span>
          <h1 className="text-[22px] font-black leading-tight tracking-tight mb-1.5">
            {event.title}
          </h1>

          {/* RSVP („Idę" + licznik + awatary) UKRYTE — wymaga kont/logowania (tier D). */}
        </div>
      </div>

      {/* ── INFO BAR ── */}
      <div className="flex bg-zinc-950 border-b border-zinc-800 overflow-x-auto scrollbar-hide">
        {[
          {
            icon: '📅',
            value: nextTerm ? nextTerm.label : (dateRange(event.start_date, event.end_date) || '—'),
            subtext: nextTerm
              ? (nextTerm.remaining > 0 ? `+ ${nextTerm.remaining} ${nextTerm.remaining === 1 ? 'kolejny termin' : 'kolejne terminy'}` : '')
              : (!isMultiDay(event.start_date, event.end_date) ? weekdayName(event.start_date) : ''),
          },
          {
            icon: '⏰',
            value: timeLabel || '—',
            // Dla wydarzeń z event_dates (cykliczne) czas trwania liczymy
            // zawsze z konkretnego terminu (occ) — każdy wiersz w event_dates
            // to jeden dzień, więc "wielodniowość" CAŁEJ serii (pierwszy
            // termin vs ostatni, różne daty) nie ma tu znaczenia. isMultiDay
            // na surowych start_date/end_date zostaje tylko dla wydarzeń BEZ
            // event_dates, gdzie start_date/end_date faktycznie mogą
            // opisywać jedno, naprawdę wielodniowe wydarzenie.
            subtext: ((event.event_dates && event.event_dates.length > 0) || !isMultiDay(event.start_date, event.end_date))
              ? durationBetween(occ.startTime, occ.endTime)
              : '',
          },
          { icon: '📍', value: event.city || event.address || '—' },
          { icon: '🎟️', value: event.is_free ? 'Wolny' : event.price_from ? `Od ${event.price_from} PLN` : 'Płatne', green: event.is_free },
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-1.5 px-2 py-1.5 border-r border-zinc-800 flex-shrink-0 last:border-r-0">
            <div className="w-6 h-6 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] flex-shrink-0">
              {item.icon}
            </div>
            <div>
              <div className={`text-[11px] font-bold ${item.green ? 'text-green-400' : 'text-white'}`}>
                {item.value}
              </div>
              {item.subtext && (
                <div className="text-[9px] text-zinc-500 mt-0.5">{item.subtext}</div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* ── TABS ── */}
      <div className="flex bg-[#111] border-b border-zinc-800">
        {tabs.map((tab, i) => (
          <button
            key={tab}
            onClick={() => setActiveTab(i)}
            className={`flex-1 py-2.5 text-[10px] font-semibold border-b-2 transition-colors ${
              activeTab === i
                ? 'text-green-400 border-green-500'
                : 'text-zinc-500 border-transparent'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* ── CONTENT ── */}
      <div className="px-4 py-4">

        {/* Tab 0: O wydarzeniu */}
        {activeTab === 0 && (
          <div>
<p className="text-[13.5px] text-zinc-200 leading-relaxed mb-4 whitespace-pre-line">
              {event.description || event.short_description
                ? linkify(event.description || event.short_description, 'dark')
                : 'Brak opisu.'}
            </p>
            <EventDatesList dates={event.event_dates} variant="dark" />

            {/* Schedule preview */}
            {hasTabs && event.schedule?.slice(0, 4).map((item: any, i: number) => (
              <div key={i} className="flex items-center gap-3 mb-3">
                <div className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" />
                <span className="text-[11px] font-bold text-green-400 min-w-[38px]">
                  {item.time}
                </span>
                <span className="text-[11px] text-zinc-300">{item.title || item.name}</span>
              </div>
            ))}
            {hasTabs && event.schedule?.length > 4 && (
              <button
                onClick={() => setActiveTab(1)}
                className="text-[11px] text-green-400 font-semibold mt-1"
              >
                Zobacz cały program ›
              </button>
            )}

            {/* Organizer */}
            {(event.organizer_name || event.website_url) && (
              <div className="mt-5 flex items-center gap-3 bg-zinc-900 border border-zinc-800 rounded-xl p-3">
                <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center text-xl flex-shrink-0">
                  🏛️
                </div>
                <div className="flex-1">
                  {event.organizer_name && (
                    <div className="text-[12px] font-bold text-white">{event.organizer_name}</div>
                  )}
                  {event.website_url && (
                    
                     <a href={event.website_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-zinc-500"
                    >
                      {event.website_url.replace(/^https?:\/\//, '')}
                    </a>
                  )}
                </div>
                {/* „Obserwuj" UKRYTE — wymaga kont + push (tier D). */}
              </div>
            )}

            {/* Kup bilety + Dodaj do kalendarza obok siebie w jednym wierszu
                (jak na desktopie) — wcześniej każdy był osobnym, pełnoszerokim
                przyciskiem pod spodem. */}
            <div className="mt-5 flex gap-2">
              {event.ticket_url && !event.is_free && (
                <a
                  href={event.ticket_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3.5 rounded-2xl text-[14px] font-black flex items-center justify-center gap-2 bg-green-500 text-black"
                >
                  🎟️ Kup bilety
                </a>
              )}
              <AddToCalendarButton event={event} variant="dark" />
            </div>
          </div>
        )}

        {/* Tab 1: Program (jeśli jest) */}
        {activeTab === 1 && hasTabs && (
          <EventSchedule schedule={event.schedule} eventDate={event.start_date} variant="dark" />
        )}

        {/* Tab: Lokalizacja */}
        {((activeTab === 1 && !hasTabs) || (activeTab === 2 && hasTabs)) && (
          <div>
            <div className="rounded-xl overflow-hidden border border-zinc-800 h-48 mb-3">
              <EventMap
                city={event.city}
                location={event.address}
                latitude={event.latitude}
                longitude={event.longitude}
              />
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex items-center justify-between">
              <div>
                <div className="text-[13px] font-bold text-white">
                  {event.venue_name || event.address || event.city}
                </div>
                {event.city && event.address && (
                  <div className="text-[11px] text-zinc-500 mt-0.5">{event.city}</div>
                )}
              </div>
              
              <a  href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-bold text-black bg-green-500 px-3 py-2 rounded-lg flex items-center gap-1.5"
              >
                Nawiguj
              </a>
            </div>

            {event.location_notes && (
              <div className="mt-3 bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex gap-2.5">
                <span className="text-[13px] flex-shrink-0">ℹ️</span>
                <p className="text-[12px] text-zinc-300 leading-relaxed whitespace-pre-line">
                  {event.location_notes}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

    </div>
  )
}